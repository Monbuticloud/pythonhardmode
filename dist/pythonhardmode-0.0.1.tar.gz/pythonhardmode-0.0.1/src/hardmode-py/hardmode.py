def hardmode():
    # pythonhardmode © 2024 by Nguyen Hoang Quoc Anh is licensed under CC BY-SA 4.0 
    global str
    global int
    global print
    global range
    str = None
    int = None
    print = None
    range = None

